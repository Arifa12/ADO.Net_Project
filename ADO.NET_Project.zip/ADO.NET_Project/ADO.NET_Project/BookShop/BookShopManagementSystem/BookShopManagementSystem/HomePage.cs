﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagementSystem
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Books obj = new Books();
            this.Hide();
            obj.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Users obj = new Users();
            this.Hide();
            obj.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bookUpdateInfo obj = new bookUpdateInfo();
            this.Hide();
            obj.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            this.Hide();
            obj.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            frmBookReport obj = new frmBookReport();
            this.Hide();
            obj.Show();
        }
    }
}
