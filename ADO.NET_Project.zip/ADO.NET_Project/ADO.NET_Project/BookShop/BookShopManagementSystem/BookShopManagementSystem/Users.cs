﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagementSystem
{
    public partial class Users : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=BookShop;Trusted_connection=true;");
        DataTable DT = new DataTable("tblUsers");
        SqlDataAdapter sda = new SqlDataAdapter();

        public Users()
        {
           
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoadGrid()
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblUsers", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            usersDGV.DataSource = dt;
            txtId.Enabled = false;
            txtBid.Enabled = false;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO tblUsers Values('" + txtUserName.Text + "'," + txtPhone.Text + ",'" + txtAddress.Text + "','" + txtPassword.Text + "','"+txtBid.Text+"')", con);
            cmd.ExecuteNonQuery();
            lblMsg.Text = "User Saved Successfully!!";
            LoadGrid();
            con.Close();
            Reset();
        }

        private void Reset()
        {
            txtId.Text = "";
            txtUserName.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtPassword.Text = "";
            txtBid.Text = "";
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Users_Load(object sender, EventArgs e)
        {
            con.Open();
            sda = new SqlDataAdapter("SELECT * FROM tblUsers", con);
            sda.Fill(DT);
            SqlCommandBuilder cmbB = new SqlCommandBuilder(sda);
            sda.InsertCommand = cmbB.GetInsertCommand();
            sda.UpdateCommand = cmbB.GetUpdateCommand();
            sda.DeleteCommand = cmbB.GetDeleteCommand();
            con.Close();
            usersDGV.DataSource = DT;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblUsers WHERE UName='" + txtUserName.Text + "'", con);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblId.Visible = true;
                txtId.Visible = true;
                txtId.Enabled = true;
                txtId.Text = dt.Rows[0]["UId"].ToString();
                txtUserName.Text = dt.Rows[0]["UName"].ToString();
                txtPhone.Text = dt.Rows[0]["UPhone"].ToString();

                txtAddress.Text = dt.Rows[0]["UAdd"].ToString();
                txtPassword.Text = dt.Rows[0]["UPass"].ToString();
                txtBid.Text = dt.Rows[0]["BId"].ToString();


                con.Close();
            }
            else
            {
                lblMsg.Text = "No Data Found";
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE tblUsers SET UName='" + txtUserName.Text + "',UPhone='" + txtPhone.Text + "',UAdd='" + txtAddress.Text + "',UPass='" + txtPassword.Text + "','"+txtBid.Text+"' WHERE UId='" + txtId.Text + "'", con);
            cmd.ExecuteNonQuery();
            lblMsg.Text = "User Updated Successfully!!";
            LoadGrid();
            con.Close();
            Reset();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            lblId.Visible = true;
            txtId.Visible = true;
            txtId.Enabled = true;
            con.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM tblUsers WHERE UId='" + txtId.Text + "'", con);
            cmd.ExecuteNonQuery();
            lblMsg.Text = "User Deleted Successfully!!";
            LoadGrid();
            con.Close();
            Reset();
        }

       

        

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Books obj = new Books();
            this.Hide();
            obj.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bookUpdateInfo obj = new bookUpdateInfo();
            this.Hide();
            obj.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            this.Hide();
            obj.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            frmBookReport obj = new frmBookReport();
            obj.Show();
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            HomePage obj = new HomePage();
            obj.Show();
            this.Hide();
        }

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    Books obj = new Books();
        //    this.Hide();
        //    obj.Show();
        //}
    }
}
