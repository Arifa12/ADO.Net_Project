﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;


namespace BookShopManagementSystem
{
    public partial class Books : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=BookShop;Trusted_connection=true");
        public Books()
        {
            InitializeComponent();
        }

        

        private void btnSave_Click(object sender, EventArgs e)
        {
            Image img = Image.FromFile(txtPhoto.Text);
            MemoryStream ms = new MemoryStream();
            img.Save(ms, ImageFormat.Bmp);
            SqlCommand cmd = new SqlCommand("INSERT INTO tblBook (BName,BAuthor,BCat,BQty,BPrice,BPic) VALUES(@n,@a,@c,@q,@p,@i)", con);
            cmd.Parameters.AddWithValue("@n", txtBname.Text);
            cmd.Parameters.AddWithValue("@a", txtAuthor.Text);
            cmd.Parameters.AddWithValue("@c", cmbCat.SelectedItem);
            cmd.Parameters.AddWithValue("@q", txtQuantity.Text);
            cmd.Parameters.AddWithValue("@p", txtPrice.Text);
            cmd.Parameters.Add(new SqlParameter("@i", SqlDbType.VarBinary) { Value = ms.ToArray() });
            
            con.Open();
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Data Inserted successfully!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
            //con.Open();
            //SqlCommand cmd = new SqlCommand("INSERT INTO tblBook (BName,BAuthor,BCat,BQty,BPrice,BPic)VALUES('" + txtBname.Text + "','" + txtAuthor.Text + "','" + cmbCat.SelectedItem.ToString() + "'," + txtQuantity.Text + ",'" + txtPrice.Text + "','"+txtPhoto.Text+"')", con);
            //cmd.ExecuteNonQuery();
            //lblMsg.Text = "Book Saved Successfully!!";
            //LoadGrid();
            //con.Close();
            //Reset();
        }
        private void LoadGrid()
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblBook", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            //lblId.Visible = false;
            //txtId.Visible = false;
            txtId.Enabled = false;
            //cmbId.Enabled = false;
        }

        private void Books_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }
        private void Reset()
        {
            //cmbId.Text = "";
            txtId.Text = "";
            txtBname.Text = "";
            txtAuthor.Text = "";
            cmbCat.Text = "";
            txtQuantity.Text = "";
            txtPrice.Text = "";
            txtPhoto.Text = "";

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void label22_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblBook WHERE BAuthor='" + txtAuthor.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                lblId.Visible = true;
                txtId.Visible = true;
                txtId.Enabled = true;
                txtId.Text = dt.Rows[0]["BId"].ToString();
                //cmbId.Visible = true;
                //cmbId.Enabled = true;
                //cmbId.Text = dt.Rows[0]["BId"].ToString();
                txtBname.Text = dt.Rows[0]["BName"].ToString();
                txtAuthor.Text = dt.Rows[0]["BAuthor"].ToString();
                cmbCat.SelectedText = dt.Rows[0]["BCat"].ToString();
                txtQuantity.Text = dt.Rows[0]["BQty"].ToString();
                txtPrice.Text = dt.Rows[0]["BPrice"].ToString();
                txtPhoto.Text = dt.Rows[0]["BPic"].ToString();


                con.Close();
            }
            else
            {
                lblMsg.Text = "No Data Found";
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {

            //con.Open();
            //SqlCommand cmd = new SqlCommand("UPDATE tblBook SET BName='" + txtBname.Text + "',BAuthor='" + txtAuthor.Text + "',BCat='" + cmbCat.SelectedItem + "',BQty='" + txtQuantity.Text + "',BPrice='" + txtPrice.Text + "',BPic='"+txtPhoto.Text+"' WHERE BId='" + txtId.Text + "'", con);
            //cmd.ExecuteNonQuery();
            //lblMsg.Text = "Book Updated Successfully!!";
            //LoadGrid();
            //con.Close();
            //Reset();
            //Image img = Image.FromFile(txtPhoto.Text);
            //MemoryStream ms = new MemoryStream();
            //img.Save(ms, ImageFormat.Bmp);
            //SqlCommand cmd = new SqlCommand("UPDATE tblBook SET BName=@n,BAuthor=@a,BCat=@c,BQty=@q,BPrice=@p,BPic=@i WHERE BId=@d", con);
            //cmd.Parameters.AddWithValue("@i", txtId.Text);
            //cmd.Parameters.AddWithValue("@n", txtBname.Text);
            //cmd.Parameters.AddWithValue("@a", txtAuthor.Text);
            //cmd.Parameters.AddWithValue("@c", cmbCat.SelectedItem);
            //cmd.Parameters.AddWithValue("@q", txtQuantity.Text);
            //cmd.Parameters.AddWithValue("@p", txtPrice.Text);
            //cmd.Parameters.Add(new SqlParameter("@i", SqlDbType.VarBinary) { Value = ms.ToArray() });

            //con.Open();
            //if (cmd.ExecuteNonQuery() > 0)
            //{
            //    MessageBox.Show("Data Updated successfully!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //con.Close();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            lblId.Visible = true;
            txtId.Visible = true;
            txtId.Enabled = true;
            //cmbId.Visible = true;
            //cmbId.Enabled = true;
            con.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM tblBook WHERE BId='" + /*cmbId.Text*/txtId.Text + "'", con);
            cmd.ExecuteNonQuery();
            lblMsg.Text = "Book Deleted Successfully!!";
            LoadGrid();
            con.Close();
            Reset();
        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            this.Hide();
            obj.Show();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtPhoto.Text = openFileDialog1.FileName;
                String path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                pictureBox5.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Users obj = new Users();
            this.Hide();
            obj.Show();
        }

        private void cmbId_SelectedIndexChanged(object sender, EventArgs e)
        {
            //SqlCommand cmd = new SqlCommand("SELECT * FROM tblBook WHERE BId=@d", con);
            //cmd.Parameters.AddWithValue("@d", cmbId.SelectedValue);
            //con.Open();
            //SqlDataReader dr = cmd.ExecuteReader();
            //if (dr.Read())
            //{
            //    txtBname.Text = dr.GetString(1);
            //    txtAuthor.Text = dr.GetString(2);
                
            //    cmbCat.SelectedItem = dr.GetInt32(3);
            //    txtQuantity.Text = dr.GetString(4);
            //    txtPrice.Text = dr.GetString(5);

            //    pictureBox5.Image = Image.FromStream(dr.GetStream(6));
            //}

            //con.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bookUpdateInfo obj = new bookUpdateInfo();
            this.Hide();
            obj.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmBookReport obj = new frmBookReport();
            obj.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            HomePage obj = new HomePage();
            obj.Show();
            this.Hide();
        }
    }
}
