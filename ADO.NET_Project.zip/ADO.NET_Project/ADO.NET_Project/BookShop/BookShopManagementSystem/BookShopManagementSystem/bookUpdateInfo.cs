﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManagementSystem
{
    
    public partial class bookUpdateInfo : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=BookShop;Integrated Security=True");
        public bookUpdateInfo()
        {
            InitializeComponent();
        }
        string imgLocation = "";

        public ImageFormat ImageFormatBmp { get; private set; }

        private void loadComboId()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select BId from tblBook", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbId.ValueMember = "BId";
            cmbId.DisplayMember = "BId";
            cmbId.DataSource = dt;
        }

        private void bookUpdateInfo_Load(object sender, EventArgs e)
        {
            loadComboId();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imgLocation = dialog.FileName.ToString();
                txtPhoto.Text = dialog.FileName;
                pictureBox5.ImageLocation = imgLocation;
            }
        }

        private void cmbId_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM tblBook WHERE BId=@i", con);
            cmd.Parameters.AddWithValue("@i", cmbId.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtBname.Text = dr[1].ToString();
                txtAuthor.Text = dr[2].ToString();

                cmbCat.SelectedItem = dr[3].ToString();
                txtQuantity.Text = dr[4].ToString();
                txtPrice.Text = dr[5].ToString();

                pictureBox5.Image = Image.FromStream(dr.GetStream(6));
            }

            con.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                Image img = Image.FromFile(txtPhoto.Text);
                MemoryStream ms = new MemoryStream();
                img.Save(ms, ImageFormat.Bmp);
                SqlCommand cmd = new SqlCommand("UPDATE tblBook SET BName=@n,BAuthor=@a,BCat=@c,BQty=@q,BPrice=@p,BPic=@i WHERE BId=@d", con);
                cmd.Parameters.AddWithValue("@d", cmbId.Text);
                cmd.Parameters.AddWithValue("@n", txtBname.Text);
                cmd.Parameters.AddWithValue("@a", txtAuthor.Text);
                cmd.Parameters.AddWithValue("@c", cmbCat.SelectedItem);
                cmd.Parameters.AddWithValue("@q", txtQuantity.Text);
                cmd.Parameters.AddWithValue("@p", txtPrice.Text);
                cmd.Parameters.Add(new SqlParameter("@i", SqlDbType.VarBinary) { Value = ms.ToArray() });

                con.Open();
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("Book Updated successfully!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
            }
            catch 
            {

                MessageBox.Show("You have to update image.");
            }
        }

        private void label22_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            this.Hide();
            obj.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Users obj = new Users();
            this.Hide();
            obj.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Books obj = new Books();
            this.Hide();
            obj.Show();
        }

        private void btnUpload_Click_1(object sender, EventArgs e)
        {

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtPhoto.Text = openFileDialog1.FileName;
                String path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                pictureBox5.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            frmBookReport obj = new frmBookReport();
            obj.Show();
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            HomePage obj = new HomePage();
            obj.Show();
            this.Hide();
        }
    }
}
