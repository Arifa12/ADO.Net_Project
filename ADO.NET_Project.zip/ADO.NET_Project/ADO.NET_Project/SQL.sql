IF EXISTS (SELECT NAME FROM sys.sysdatabases WHERE NAME='BookShop')
DROP DATABASE BookShop
GO

/*CREATE DATABASE BookShop
ON
(
	name='BookShop_DATA',
	filename='C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\BookShop_DATA.mdf',
	size=50mb,
	maxsize=500mb,
	filegrowth=10%
)
LOG ON
(
	name='BookShop_LOG',
	filename='C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\BookShop_LOG.ldf',
	size=20mb,
	maxsize=300mb,
	filegrowth=1mb
)
GO */
CREATE DATABASE BookShop
GO
USE BookShop
GO
CREATE TABLE tblBook
(
	BId INT PRIMARY KEY IDENTITY,
	BName VARCHAR(100) NOT NULL,
	BAuthor VARCHAR(50) NOT NULL,
	BCat VARCHAR(50) NOT NULL,
	BQty INT NOT NULL,
	BPrice MONEY NOT NULL,
	BPic VARBINARY(MAX) Not NULL
)
GO
CREATE TABLE tblUsers
(
	UId INT PRIMARY KEY IDENTITY,
	UName VARCHAR(50) NOT NULL,
	UPhone NCHAR(20) NOT NULL,
	UAdd VARCHAR(50) NOT NULL,
	UPass NCHAR(20) NOT NULL,
	

)
GO
CREATE TABLE tblBill
(
	BillId INT PRIMARY KEY IDENTITY,
	UName VARCHAR (50) NOT NULL,
	ClientName VARCHAR (50) NOT NULL,
	Amount INT NOT NULL
)